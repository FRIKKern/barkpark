defmodule Color.Palette.Tonal do
  @moduledoc """
  A **tonal scale** — N shades of one hue, from light to dark —
  generated from a single seed colour.

  This is the algorithm behind Tailwind's `blue-50` … `blue-950`,
  Radix's 12-step scales, Open Color, and the per-role tonal
  palettes inside Material Design 3.

  ## Algorithm

  1. Convert the seed to **Oklch**.

  2. For each requested stop, compute a target lightness `L` by
     interpolating along a curve between `light_anchor` (the
     lightness of the lightest stop) and `dark_anchor` (the
     lightness of the darkest stop). The interpolation is in
     stop-space — equally spaced positions in the stop list map
     to equally spaced lightnesses.

  3. **Damp the chroma** at the extremes. Tints near white and
     shades near black cannot carry as much chroma as a mid-tone
     of the same hue without falling out of the sRGB gamut. The
     library multiplies the seed's chroma by `sin(π · L)` to taper
     it smoothly toward zero at `L = 0` and `L = 1`.

  4. Optionally apply **hue drift**. When `hue_drift: true`, the
     hue rotates slightly toward yellow (~90°) at the light end
     and toward blue (~270°) at the dark end. This matches how
     human vision perceives lightness — a phenomenon known as the
     Hunt effect — and gives the scale a more natural feel.

  5. **Cap to a fraction of the gamut envelope**. When
     `:chroma_ceiling` is below `1.0`, cap each stop's chroma at
     `ceiling × max_chroma(L, H, gamut)`. This produces a more
     muted ramp that sits strictly inside the gamut boundary
     instead of hugging it. At the default `1.0` this step is a
     no-op.

  6. **Snap to seed**. Find the generated stop whose lightness is
     closest to the seed's lightness and replace it with the seed
     itself. The `:seed_stop` field on the resulting struct
     records which stop received the seed. Note that when
     `:chroma_ceiling` is below `1.0` and the seed sits near the
     gamut boundary, the seed will be visibly more saturated than
     its capped neighbours — pick a wider `:gamut` instead if you
     want a smoother ramp without muting the seed.

  7. **Gamut-map** each stop into the requested working space
     (default `:SRGB`) using the CSS Color 4 Oklch binary-search
     algorithm provided by `Color.Gamut.to_gamut/3`.

  ## Stops

  By default the stops are Tailwind's `[50, 100, 200, …, 950]`,
  but any list of integer or atom labels may be supplied. The
  algorithm cares only about position in the list, not the label
  values themselves — `["lightest", "light", "mid", "dark",
  "darkest"]` works just as well.

  ## Example

      iex> palette = Color.Palette.Tonal.new("#3b82f6")
      iex> Map.fetch!(palette.stops, 50) |> Color.to_hex()
      "#f5f9ff"

      iex> palette = Color.Palette.Tonal.new("#3b82f6")
      iex> Map.fetch!(palette.stops, 950) |> Color.to_hex()
      "#000827"

  """

  @default_stops [50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 950]
  @default_light_anchor 0.98
  @default_dark_anchor 0.15
  @hue_drift_light 90.0
  @hue_drift_dark 270.0
  @hue_drift_amount 8.0

  defstruct [
    :name,
    :seed,
    :seed_stop,
    :stops,
    :options
  ]

  @type stop_label :: integer() | atom() | binary()

  @type t :: %__MODULE__{
          name: binary() | nil,
          seed: Color.SRGB.t(),
          seed_stop: stop_label(),
          stops: %{stop_label() => Color.SRGB.t()},
          options: keyword()
        }

  @doc """
  Generates a tonal scale from a seed colour.

  See the moduledoc for a description of the algorithm and
  `Color.Palette.tonal/2` for option details.

  ### Arguments

  * `seed` is anything accepted by `Color.new/1`.

  ### Options

  See `Color.Palette.tonal/2`.

  ### Returns

  * A `Color.Palette.Tonal` struct.

  ### Examples

      iex> palette = Color.Palette.Tonal.new("#3b82f6", name: "brand")
      iex> palette.name
      "brand"
      iex> palette.seed_stop in [400, 500]
      true

  """
  @spec new(Color.input(), keyword()) :: t()
  def new(seed, options \\ []) do
    options = validate_options!(options)

    {:ok, seed_srgb} = Color.new(seed)
    {:ok, seed_oklch} = Color.convert(seed_srgb, Color.Oklch)

    stops = Keyword.fetch!(options, :stops)
    light_anchor = Keyword.fetch!(options, :light_anchor)
    dark_anchor = Keyword.fetch!(options, :dark_anchor)
    hue_drift? = Keyword.fetch!(options, :hue_drift)
    gamut = Keyword.fetch!(options, :gamut)
    chroma_ceiling = Keyword.fetch!(options, :chroma_ceiling)

    base_h = seed_oklch.h || 0.0
    base_c = seed_oklch.c || 0.0

    seed_l = seed_oklch.l || 0.5
    num_stops = length(stops)

    # Normalise the chroma ceiling so the damping curve passes
    # through the seed's chroma at the seed's lightness. Without
    # this, generated neighbours are damped by sin(π · L) while the
    # seed itself keeps its raw chroma, leaving the seed visibly
    # more saturated than its neighbours.
    peak_c = peak_chroma(base_c, seed_l)

    # First pass: find which stop the seed would snap to, and
    # compute the curve lightness at that position.
    snap_index = nearest_index(stops, light_anchor, dark_anchor, seed_l)
    snap_position = position_for(snap_index, num_stops)

    # Second pass: generate every stop using a lightness curve
    # that passes through the seed's actual lightness at the snap
    # position. We do this by splitting the curve into two
    # segments — [light_anchor, seed_l] for stops above the snap,
    # [seed_l, dark_anchor] for stops at or below — so adjacent
    # stops transition smoothly through the seed instead of
    # hitting a cliff.
    generated =
      stops
      |> Enum.with_index()
      |> Enum.map(fn {label, index} ->
        position = position_for(index, num_stops)

        l =
          cond do
            index < snap_index ->
              # Above the snap: lerp from light_anchor to seed_l.
              t = position / snap_position
              lerp(light_anchor, seed_l, t)

            index == snap_index ->
              seed_l

            true ->
              # Below the snap: lerp from seed_l to dark_anchor.
              remaining = 1.0 - snap_position
              t = if remaining == 0.0, do: 1.0, else: (position - snap_position) / remaining
              lerp(seed_l, dark_anchor, t)
          end

        curve_c = peak_c * chroma_damping(l)
        h = if hue_drift?, do: drift_hue(base_h, position), else: base_h

        c =
          if chroma_ceiling < 1.0 do
            min(curve_c, chroma_ceiling * max_chroma_at(l, h, gamut))
          else
            curve_c
          end

        oklch = %Color.Oklch{l: l, c: c, h: h, alpha: seed_srgb.alpha}
        {:ok, mapped} = Color.Gamut.to_gamut(oklch, gamut)
        {label, mapped, l}
      end)

    seed_stop_label = Enum.at(stops, snap_index)

    stops_map =
      Enum.into(generated, %{}, fn
        {^seed_stop_label, _mapped, _l} -> {seed_stop_label, seed_srgb}
        {label, mapped, _l} -> {label, mapped}
      end)

    %__MODULE__{
      name: Keyword.get(options, :name),
      seed: seed_srgb,
      seed_stop: seed_stop_label,
      stops: stops_map,
      options: options
    }
  end

  @doc """
  Fetches the colour at a given stop label.

  ### Arguments

  * `palette` is a `Color.Palette.Tonal` struct.

  * `label` is the stop label to look up.

  ### Returns

  * `{:ok, color}` on success, `:error` if the label is unknown.

  ### Examples

      iex> palette = Color.Palette.Tonal.new("#3b82f6")
      iex> {:ok, _color} = Color.Palette.Tonal.fetch(palette, 500)
      iex> Color.Palette.Tonal.fetch(palette, :missing)
      :error

  """
  @spec fetch(t(), stop_label()) :: {:ok, Color.SRGB.t()} | :error
  def fetch(%__MODULE__{stops: stops}, label), do: Map.fetch(stops, label)

  @doc """
  Returns the list of stop labels in generation order.

  ### Arguments

  * `palette` is a `Color.Palette.Tonal` struct.

  ### Returns

  * A list of stop labels.

  ### Examples

      iex> palette = Color.Palette.Tonal.new("#3b82f6")
      iex> Color.Palette.Tonal.labels(palette)
      [50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 950]

  """
  @spec labels(t()) :: [stop_label()]
  def labels(%__MODULE__{options: options}), do: Keyword.fetch!(options, :stops)

  @doc """
  Emits the palette as a W3C [Design Tokens Community Group](https://www.designtokens.org/)
  color-token group.

  The result is a nested map ready for `:json.encode/1`. Each
  stop becomes a DTCG color token keyed by its label.

  ### Arguments

  * `palette` is a `Color.Palette.Tonal` struct.

  ### Options

  * `:space` is the colour space to emit components in. Any
    module accepted by `Color.convert/2`. Default `Color.Oklch`.

  * `:name` overrides the group name. Defaults to the palette's
    `:name` field, or `"color"` if unset.

  ### Returns

  * A map shaped as `%{"<name>" => %{"<stop>" => token, ...}}`.

  ### Examples

      iex> palette = Color.Palette.Tonal.new("#3b82f6", name: "blue")
      iex> tokens = Color.Palette.Tonal.to_tokens(palette)
      iex> tokens["blue"]["500"]["$type"]
      "color"

  """
  @spec to_tokens(t(), keyword()) :: map()
  def to_tokens(%__MODULE__{} = palette, options \\ []) do
    space = Keyword.get(options, :space, Color.Oklch)
    name = Keyword.get(options, :name, palette.name || "color")

    stop_tokens =
      Enum.into(palette.stops, %{}, fn {label, color} ->
        {to_string(label), Color.DesignTokens.encode_token(color, space: space)}
      end)

    %{name => stop_tokens}
  end

  @doc """
  Returns `true` when every stop in the palette is inside the
  given RGB working space.

  Convenient for CI checks — fail the build if a palette
  generated against one working space slips outside another's
  gamut.

  ### Arguments

  * `palette` is a `Color.Palette.Tonal` struct.

  * `working_space` is an RGB working-space atom. Defaults to
    `:SRGB`.

  ### Returns

  * A boolean.

  ### Examples

      iex> palette = Color.Palette.Tonal.new("#3b82f6")
      iex> Color.Palette.Tonal.in_gamut?(palette, :SRGB)
      true

  """
  @spec in_gamut?(t(), Color.Types.working_space()) :: boolean()
  def in_gamut?(%__MODULE__{stops: stops}, working_space \\ :SRGB) do
    Enum.all?(stops, fn {_label, color} ->
      Color.Gamut.in_gamut?(color, working_space)
    end)
  end

  @doc """
  Returns a detailed per-stop gamut report.

  Useful for actionable CI output: which specific stops fell
  outside the target gamut and need attention.

  ### Arguments

  * `palette` is a `Color.Palette.Tonal` struct.

  * `working_space` is an RGB working-space atom. Defaults to
    `:SRGB`.

  ### Returns

  * A map with:

    * `:working_space` — the space the check was performed against.

    * `:in_gamut?` — `true` if every stop is inside, else `false`.

    * `:stops` — list of `%{label, color, in_gamut?}` maps, one
      per stop, in label order.

    * `:out_of_gamut` — list of the same map shape, filtered to
      stops that are outside the target space.

  ### Examples

      iex> palette = Color.Palette.Tonal.new("#3b82f6")
      iex> report = Color.Palette.Tonal.gamut_report(palette, :SRGB)
      iex> report.in_gamut?
      true
      iex> report.out_of_gamut
      []

  """
  @spec gamut_report(t(), Color.Types.working_space()) :: map()
  def gamut_report(%__MODULE__{} = palette, working_space \\ :SRGB) do
    stops =
      palette
      |> labels()
      |> Enum.map(fn label ->
        color = Map.fetch!(palette.stops, label)
        in_gamut? = Color.Gamut.in_gamut?(color, working_space)
        %{label: label, color: color, in_gamut?: in_gamut?}
      end)

    %{
      working_space: working_space,
      in_gamut?: Enum.all?(stops, & &1.in_gamut?),
      stops: stops,
      out_of_gamut: Enum.reject(stops, & &1.in_gamut?)
    }
  end

  @doc """
  Emits the palette as a block of **CSS custom properties**,
  one per stop, keyed by the palette name.

  Output is a plain binary, ready to write to a stylesheet.

  ### Arguments

  * `palette` is a `Color.Palette.Tonal` struct.

  ### Options

  * `:name` overrides the property prefix. Defaults to the
    palette's `:name` field, or `"color"` if unset.

  * `:selector` is the CSS selector the properties are declared
    on. Default `":root"`.

  ### Returns

  * A binary containing a single CSS rule.

  ### Examples

      iex> palette = Color.Palette.Tonal.new("#3b82f6", name: "blue")
      iex> css = Color.Palette.Tonal.to_css(palette)
      iex> String.contains?(css, "--blue-500:")
      true

      iex> palette = Color.Palette.Tonal.new("#3b82f6")
      iex> Color.Palette.Tonal.to_css(palette, name: "brand", selector: "[data-theme]")
      ...> |> String.starts_with?("[data-theme] {")
      true

  """
  @spec to_css(t(), keyword()) :: binary()
  def to_css(%__MODULE__{} = palette, options \\ []) do
    name = Keyword.get(options, :name, palette.name || "color")
    selector = Keyword.get(options, :selector, ":root")
    labels = labels(palette)

    body =
      Enum.map_join(labels, "", fn label ->
        color = Map.fetch!(palette.stops, label)
        "  --#{name}-#{label}: #{Color.to_hex(color)};\n"
      end)

    "#{selector} {\n#{body}}\n"
  end

  @doc """
  Emits the palette as a **Tailwind CSS v4 `@theme` block** —
  CSS-native theme variables using the `--color-*` namespace
  that Tailwind v4 expects.

  ### Arguments

  * `palette` is a `Color.Palette.Tonal` struct.

  ### Options

  * `:name` overrides the key name. Defaults to the palette's
    `:name` field, or `"color"` if unset.

  ### Returns

  * A binary containing a `@theme` block ready to paste into a
    Tailwind v4 CSS file.

  ### Examples

      iex> palette = Color.Palette.Tonal.new("#3b82f6", name: "blue")
      iex> config = Color.Palette.Tonal.to_tailwind(palette)
      iex> String.contains?(config, "--color-blue-500:")
      true
      iex> String.contains?(config, "@theme")
      true

  """
  @spec to_tailwind(t(), keyword()) :: binary()
  def to_tailwind(%__MODULE__{} = palette, options \\ []) do
    name = Keyword.get(options, :name, palette.name || "color")
    labels = labels(palette)

    body =
      Enum.map_join(labels, "", fn label ->
        color = Map.fetch!(palette.stops, label)
        "  --color-#{name}-#{label}: #{Color.to_hex(color)};\n"
      end)

    "@theme {\n#{body}}\n"
  end

  # ---- algorithm helpers --------------------------------------------------

  # Position of stop `index` in `[0, 1]` along the light-to-dark
  # axis. With one stop we put it at the midpoint.
  defp position_for(_index, 1), do: 0.5
  defp position_for(index, count), do: index / (count - 1)

  defp lerp(a, b, t), do: a + (b - a) * t

  # sin(π · L): zero at L = 0 and L = 1, peaks at L = 0.5. Tapers
  # chroma toward white and black so light tints don't look muddy
  # and dark shades don't blow past the sRGB gamut.
  defp chroma_damping(l), do: :math.sin(:math.pi() * clamp01(l))

  # Solve for the pre-damping chroma ceiling that makes
  # `peak_c · chroma_damping(seed_l) = seed_c`. Floor the divisor
  # so seeds with extreme lightness don't blow peak_c up to
  # unreasonable values.
  @min_seed_damping 0.05
  defp peak_chroma(base_c, seed_l) do
    damping = chroma_damping(seed_l)
    if damping > @min_seed_damping, do: base_c / damping, else: base_c
  end

  # Binary-search for the maximum chroma that is in gamut at the
  # given lightness and hue, for the given working space. Used
  # only when :chroma_ceiling is below 1.0.
  @max_chroma_search_upper 0.5
  @max_chroma_search_iters 25
  defp max_chroma_at(l, h, gamut) do
    do_max_chroma_search(l, h, gamut, 0.0, @max_chroma_search_upper, @max_chroma_search_iters)
  end

  defp do_max_chroma_search(_l, _h, _gamut, lo, _hi, 0), do: lo

  defp do_max_chroma_search(l, h, gamut, lo, hi, iters) do
    mid = (lo + hi) / 2
    test = %Color.Oklch{l: l, c: mid, h: h, alpha: 1.0}

    if Color.Gamut.in_gamut?(test, gamut) do
      do_max_chroma_search(l, h, gamut, mid, hi, iters - 1)
    else
      do_max_chroma_search(l, h, gamut, lo, mid, iters - 1)
    end
  end

  # Drift hue toward yellow at the light end and toward blue at
  # the dark end. The drift amount is small (a few degrees) and
  # scales with distance from the midpoint.
  defp drift_hue(h, position) do
    # signed offset in [-1, 1]: -1 = lightest, +1 = darkest.
    delta = (position - 0.5) * 2

    target =
      if delta < 0, do: @hue_drift_light, else: @hue_drift_dark

    # Shortest-path rotation from h toward target, scaled by
    # |delta| · @hue_drift_amount.
    diff = shortest_hue_diff(h, target)
    new_h = h + diff * abs(delta) * (@hue_drift_amount / 180.0)
    wrap_hue(new_h)
  end

  defp shortest_hue_diff(from, to) do
    raw = to - from

    cond do
      raw > 180.0 -> raw - 360.0
      raw < -180.0 -> raw + 360.0
      true -> raw
    end
  end

  defp wrap_hue(h) when h < 0.0, do: wrap_hue(h + 360.0)
  defp wrap_hue(h) when h >= 360.0, do: wrap_hue(h - 360.0)
  defp wrap_hue(h), do: h

  defp clamp01(v) when v < 0.0, do: 0.0
  defp clamp01(v) when v > 1.0, do: 1.0
  defp clamp01(v), do: v

  # Returns the index in the stop list whose curve lightness is
  # closest to the seed's lightness.
  defp nearest_index(stops, light_anchor, dark_anchor, seed_l) do
    count = length(stops)

    stops
    |> Enum.with_index()
    |> Enum.min_by(fn {_label, index} ->
      position = position_for(index, count)
      curve_l = lerp(light_anchor, dark_anchor, position)
      abs(curve_l - seed_l)
    end)
    |> elem(1)
  end

  # ---- options validation -------------------------------------------------

  @valid_keys [
    :stops,
    :light_anchor,
    :dark_anchor,
    :hue_drift,
    :gamut,
    :chroma_ceiling,
    :name
  ]

  defp validate_options!(options) do
    Enum.each(Keyword.keys(options), fn key ->
      unless key in @valid_keys do
        raise Color.PaletteError,
          reason: :unknown_option,
          detail: "#{inspect(key)} (valid options: #{inspect(@valid_keys)})"
      end
    end)

    options =
      options
      |> Keyword.put_new(:stops, @default_stops)
      |> Keyword.put_new(:light_anchor, @default_light_anchor)
      |> Keyword.put_new(:dark_anchor, @default_dark_anchor)
      |> Keyword.put_new(:hue_drift, false)
      |> Keyword.put_new(:gamut, :SRGB)
      |> Keyword.put_new(:chroma_ceiling, 1.0)

    stops = Keyword.fetch!(options, :stops)

    cond do
      not is_list(stops) ->
        raise Color.PaletteError,
          reason: :invalid_stops,
          detail: ":stops must be a list"

      stops == [] ->
        raise Color.PaletteError,
          reason: :empty_stops,
          detail: ":stops must contain at least one label"

      length(Enum.uniq(stops)) != length(stops) ->
        raise Color.PaletteError,
          reason: :duplicate_stops,
          detail: ":stops must not contain duplicates"

      true ->
        :ok
    end

    light = Keyword.fetch!(options, :light_anchor)
    dark = Keyword.fetch!(options, :dark_anchor)

    unless is_number(light) and light >= 0.0 and light <= 1.0 do
      raise Color.PaletteError,
        reason: :invalid_anchor,
        detail: ":light_anchor must be a number in [0.0, 1.0]"
    end

    unless is_number(dark) and dark >= 0.0 and dark <= 1.0 do
      raise Color.PaletteError,
        reason: :invalid_anchor,
        detail: ":dark_anchor must be a number in [0.0, 1.0]"
    end

    unless light > dark do
      raise Color.PaletteError,
        reason: :invalid_anchor,
        detail: ":light_anchor (#{light}) must be greater than :dark_anchor (#{dark})"
    end

    ceiling = Keyword.fetch!(options, :chroma_ceiling)

    unless is_number(ceiling) and ceiling > 0.0 and ceiling <= 1.0 do
      raise Color.PaletteError,
        reason: :invalid_chroma_ceiling,
        detail: ":chroma_ceiling must be a number in (0.0, 1.0]"
    end

    options
  end
end
