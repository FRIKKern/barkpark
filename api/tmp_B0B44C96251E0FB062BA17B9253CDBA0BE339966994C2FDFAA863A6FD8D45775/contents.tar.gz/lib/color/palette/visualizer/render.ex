defmodule Color.Palette.Visualizer.Render do
  @moduledoc false

  # Shared HTML helpers. Pure functions, no templates, iodata in /
  # iodata out. All literal markup is written as double-quoted
  # strings so it's immune to Elixir's sigil-vs-keyword edge
  # cases around colons.

  @doc "HTML-escapes a binary."
  @spec escape(iodata()) :: iodata()
  def escape(iodata) when is_list(iodata), do: Enum.map(iodata, &escape/1)

  def escape(binary) when is_binary(binary) do
    binary
    |> String.replace("&", "&amp;")
    |> String.replace("<", "&lt;")
    |> String.replace(">", "&gt;")
    |> String.replace("\"", "&quot;")
    |> String.replace("'", "&#39;")
  end

  def escape(other), do: escape(to_string(other))

  @doc "Wraps body iodata in the full HTML page chrome."
  def page(assigns) do
    title = Keyword.fetch!(assigns, :title)
    active = Keyword.fetch!(assigns, :active)
    seed = Keyword.get(assigns, :seed, "")
    body = Keyword.fetch!(assigns, :body)
    error = Keyword.get(assigns, :error)
    base = Keyword.fetch!(assigns, :base)
    extra_fields = Keyword.get(assigns, :extra_fields, [])
    tab_params = Keyword.get(assigns, :tab_params, %{})
    hide_seed = Keyword.get(assigns, :hide_seed, false)

    [
      "<!doctype html><html lang=\"en\"><head>",
      "<meta charset=\"utf-8\">",
      "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">",
      "<title>",
      escape(title),
      " — Color.Palette.Visualizer</title>",
      "<link rel=\"stylesheet\" href=\"",
      escape(base),
      "/assets/style.css\">",
      "<link rel=\"icon\" type=\"image/png\" href=\"",
      escape(base),
      "/assets/logo.png\">",
      "</head><body>",
      header(active, seed, base, extra_fields, tab_params, hide_seed),
      "<main class=\"vz-main\">",
      error_block(error),
      body,
      footer(),
      "</main></body></html>"
    ]
  end

  defp header(active, seed, base, extra_fields, tab_params, hide_seed) do
    tabs = [
      {"tonal", "Tonal"},
      {"theme", "Theme"},
      {"contrast", "Contrast"},
      {"scale", "Scale"},
      {"gamut", "Gamut"},
      {"sort", "Sort"},
      {"spectrum", "Spectrum"}
    ]

    seed_hex = resolve_hex(seed, "#3b82f6")

    [
      "<header class=\"vz-header\">",
      "<a class=\"vz-brand\" href=\"",
      escape(base),
      "/\"><img src=\"",
      escape(base),
      "/assets/logo.png\" alt=\"\" class=\"vz-logo\" width=\"32\" height=\"32\">",
      "<h1>Color.Palette.Visualizer</h1></a>",
      "<nav class=\"vz-tabs\">",
      Enum.map(tabs, fn {path, label} ->
        cls = if path == active, do: "active", else: ""
        extras = Map.get(tab_params, path, %{})
        query = tab_query_string(seed, extras)

        [
          "<a href=\"",
          escape(base),
          "/",
          path,
          query,
          "\" class=\"",
          cls,
          "\">",
          label,
          "</a>"
        ]
      end),
      "</nav>",
      "<form class=\"vz-form\" method=\"get\" action=\"",
      escape(base),
      "/",
      active,
      "\">",
      seed_input(seed, seed_hex, hide_seed),
      "<input type=\"hidden\" name=\"seed_picker_initial\" value=\"",
      escape(seed_hex),
      "\">",
      extra_fields,
      "<button type=\"submit\">Update</button>",
      "</form>",
      "</header>"
    ]
  end

  # Renders the seed picker + text input, or a hidden field when
  # the active tab doesn't use the seed (so cross-tab navigation
  # still preserves the last seed the user set elsewhere).
  defp seed_input(seed, seed_hex, false) do
    [
      "<label>seed <input type=\"color\" name=\"seed_picker\" value=\"",
      escape(seed_hex),
      "\"> <input type=\"text\" name=\"seed\" value=\"",
      escape(seed),
      "\" placeholder=\"#3b82f6 or rebeccapurple or oklch(...)\"></label>"
    ]
  end

  defp seed_input(seed, _seed_hex, true) do
    ["<input type=\"hidden\" name=\"seed\" value=\"", escape(seed), "\">"]
  end

  # Builds the `?seed=…&k=v&…` query string appended to each tab's
  # nav link. The seed is always included; callers can supply
  # per-tab extras (e.g., palette_gamut) via the `tab_params` map
  # on `Render.page/1`.
  defp tab_query_string(seed, extras) when extras == %{} do
    "?seed=" <> URI.encode_www_form(seed)
  end

  defp tab_query_string(seed, extras) do
    base = "?seed=" <> URI.encode_www_form(seed)

    extra_pairs =
      extras
      |> Enum.map(fn {k, v} ->
        URI.encode_www_form(to_string(k)) <> "=" <> URI.encode_www_form(to_string(v))
      end)
      |> Enum.join("&")

    base <> "&" <> extra_pairs
  end

  @doc """
  Resolves any colour input to a 7-char hex string suitable for
  `<input type="color">`. Falls back to `default` if parsing
  fails. Used to initialise the native colour picker.
  """
  @spec resolve_hex(binary() | nil, binary()) :: binary()
  def resolve_hex(nil, default), do: default

  def resolve_hex(input, default) do
    case Color.new(input) do
      {:ok, srgb} -> Color.to_hex(srgb)
      _ -> default
    end
  rescue
    _ -> default
  end

  defp error_block(nil), do: []

  defp error_block(message) do
    ["<div class=\"vz-error\">", escape(message), "</div>"]
  end

  defp footer do
    [
      "<div class=\"vz-footer\">",
      "Generated by ",
      "<a href=\"https://hexdocs.pm/color/Color.Palette.html\">Color.Palette</a>",
      "</div>"
    ]
  end

  @doc "Renders one tonal-scale strip as a grid of swatches."
  def tonal_strip(%Color.Palette.Tonal{} = palette) do
    labels = Color.Palette.Tonal.labels(palette)

    [
      "<div class=\"vz-strip\">",
      Enum.map(labels, &swatch(palette, &1)),
      "</div>"
    ]
  end

  defp swatch(palette, label) do
    color = Map.fetch!(palette.stops, label)
    hex = Color.to_hex(color)
    {:ok, oklch} = Color.convert(color, Color.Oklch)
    text_color = text_on(color)

    seed_class = if label == palette.seed_stop, do: " vz-seed", else: ""

    [
      "<div class=\"vz-swatch",
      seed_class,
      "\">",
      "<div class=\"vz-chip\" style=\"background:",
      hex,
      ";color:",
      text_color,
      "\">",
      escape(to_string(label)),
      "</div>",
      "<div class=\"vz-meta\">",
      "<div class=\"vz-hex\">",
      escape(hex),
      "</div>",
      "<div>L\u00A0",
      fmt(oklch.l, 3),
      " C\u00A0",
      fmt(oklch.c, 3),
      " H\u00A0",
      fmt(oklch.h, 1),
      "</div>",
      contrast_pair(color),
      "</div>",
      "</div>"
    ]
  end

  defp contrast_pair(color) do
    w_ratio = Color.Contrast.wcag_ratio(color, "white")
    b_ratio = Color.Contrast.wcag_ratio(color, "black")

    [
      "<div class=\"vz-contrast\">",
      "<span class=\"",
      pass_class(w_ratio),
      "\">⬜ ",
      fmt(w_ratio, 2),
      "</span>",
      "<span class=\"",
      pass_class(b_ratio),
      "\">⬛ ",
      fmt(b_ratio, 2),
      "</span>",
      "</div>"
    ]
  end

  defp pass_class(r) when r >= 4.5, do: "pass"
  defp pass_class(r) when r >= 3.0, do: "warn"
  defp pass_class(_), do: "fail"

  @doc "\"#000\" or \"#fff\", whichever has higher contrast against the given colour."
  @spec text_on(Color.input()) :: binary()
  def text_on(color) do
    white = Color.Contrast.wcag_ratio(color, "white")
    black = Color.Contrast.wcag_ratio(color, "black")
    if black > white, do: "#000", else: "#fff"
  end

  @doc "Formats a float to N decimal places."
  @spec fmt(number(), non_neg_integer()) :: binary()
  def fmt(n, places) when is_number(n), do: :erlang.float_to_binary(n * 1.0, decimals: places)
  def fmt(_, _), do: "—"

  @doc """
  Pretty-prints a JSON-encodable value (map / list / scalar) as
  an indented binary, using Erlang's `:json` for encoding leaves
  and a small hand-rolled formatter for layout. Sorts map keys
  alphabetically so the output is stable.
  """
  @spec pretty_json(term()) :: binary()
  def pretty_json(value), do: format_value(value, 0)

  defp format_value(map, depth) when is_map(map) do
    if map_size(map) == 0 do
      "{}"
    else
      entries =
        map
        |> Enum.sort_by(fn {k, _} -> k end)
        |> Enum.map(fn {k, v} ->
          indent(depth + 1) <>
            IO.iodata_to_binary(:json.encode(k)) <> ": " <> format_value(v, depth + 1)
        end)
        |> Enum.join(",\n")

      "{\n" <> entries <> "\n" <> indent(depth) <> "}"
    end
  end

  defp format_value(list, depth) when is_list(list) do
    if list == [] do
      "[]"
    else
      inner = Enum.map_join(list, ", ", fn v -> format_value(v, depth) end)
      "[" <> inner <> "]"
    end
  end

  defp format_value(other, _depth), do: IO.iodata_to_binary(:json.encode(other))

  defp indent(depth), do: String.duplicate("  ", depth)
end
