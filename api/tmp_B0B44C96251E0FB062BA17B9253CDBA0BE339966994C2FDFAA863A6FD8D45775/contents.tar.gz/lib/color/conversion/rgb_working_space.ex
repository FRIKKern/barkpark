defmodule Color.RGB.WorkingSpace do
  # RGB Observer angle is CIE1931 2°
  @rgb_observer_angle 2

  @rgb_working_space_table """
  # Name    Gamma WP     xr      yr       Yr       xg     yg       Yg        xb      yb      bY

  # http://www.brucelindbloom.com
  Adobe      2.2  D65  0.6400  0.3300  0.297361  0.2100  0.7100  0.627355  0.1500  0.0600  0.075285
  Apple      1.8  D65  0.6250  0.3400  0.244634  0.2800  0.5950  0.672034  0.1550  0.0700  0.083332
  Best       2.2  D50  0.7347  0.2653  0.228457  0.2150  0.7750  0.737352  0.1300  0.0350  0.034191
  Beta       2.2  D50  0.6888  0.3112  0.303273  0.1986  0.7551  0.663786  0.1265  0.0352  0.032941
  Bruce      2.2  D65  0.6400  0.3300  0.240995  0.2800  0.6500  0.683554  0.1500  0.0600  0.075452
  CIE        2.2  E    0.7350  0.2650  0.176204  0.2740  0.7170  0.812985  0.1670  0.0090  0.010811
  ColorMatch 1.8  D50  0.6300  0.3400  0.274884  0.2950  0.6050  0.658132  0.1500  0.0750  0.066985
  Don        2.2  D50  0.6960  0.3000  0.278350  0.2150  0.7650  0.687970  0.1300  0.0350  0.033680
  ECI         L*  D50  0.6700  0.3300  0.320250  0.2100  0.7100  0.602071  0.1400  0.0800  0.077679
  Ekta_Space 2.2  D50  0.6950  0.3050  0.260629  0.2600  0.7000  0.734946  0.1100  0.0050  0.004425
  NTSC       2.2  C    0.6700  0.3300  0.298839  0.2100  0.7100  0.586811  0.1400  0.0800  0.114350
  PAL        2.2  D65  0.6400  0.3300  0.222021  0.2900  0.6000  0.706645  0.1500  0.0600  0.071334
  # SECAM and PAL are the same
  SECAM      2.2  D65  0.6400  0.3300  0.222021  0.2900  0.6000  0.706645  0.1500  0.0600  0.071334
  ProPhoto   1.8  D50  0.7347  0.2653  0.288040  0.1596  0.8404  0.711874  0.0366  0.0001  0.000086
  SMPTE      2.2  D65  0.6300  0.3400  0.212395  0.3100  0.5950  0.701049  0.1550  0.0700  0.086556
  SRGB      ≈2.2  D65  0.6400  0.3300  0.212656  0.3000  0.6000  0.715158  0.1500  0.0600  0.072186
  Wide_Gamut 2.2  D50  0.7350  0.2650  0.258187  0.1150  0.8260  0.724938  0.1570  0.0180  0.016875

  # https://en.wikipedia.org/wiki/DCI-P3
  P3_D65    ≈2.2  D65  0.680   0.320   1.0       0.265   0.690   1.0       0.150   0.060   1.0
  P3_DCI     2.6  DCI  0.680   0.320   1.0       0.265   0.690   1.0       0.150   0.060   1.0
  P3_D60     2.6  D60  0.680   0.320   1.0       0.265   0.690   1.0       0.150   0.060   1.0
  DCI_P3P    2.6  DCI  0.740   0.270   1.0       0.220   0.780   1.0       0.090  -0.090   1.0
  Cinema    ≈2.2  D65  0.740   0.270   1.0       0.170   1.140   1.0       0.080  -0.100   1.0

  # https://en.wikipedia.org/wiki/Rec.1.0709
  Rec709    ≈709  D65  0.64   0.33     1.0       0.30    0.60    1.0       0.15    0.06    1.0

  # https://en.wikipedia.org/wiki/Rec.1.02020
  Rec2020   ≈2020 D65  0.708  0.292    1.0       0.170   0.797   1.0       0.131   0.046   1.0

  # Here we use the following definitions for gamma:
  # ≈2.2   means the sRGB transfer function
  # ≈709   means the Rec709 transfer function
  # ≈2020  means the Rec2020 transfer function

  # Some white point definitions are not standard
  # D60
  # DCI

  """

  @rgb_working_space @rgb_working_space_table
                     |> String.split("\n", trim: true)
                     |> Enum.reject(&String.starts_with?(&1, "#"))
                     |> Enum.map(fn line ->
                       [working_space, gamma, illuminant | data] =
                         line
                         |> String.split("#")
                         |> hd()
                         |> String.split("\s", trim: true)
                         |> Enum.map(fn elem ->
                           case Float.parse(elem) do
                             {float, ""} -> float
                             :error -> elem
                           end
                         end)

                       {:ok, illuminant} = Color.Tristimulus.validate_illuminant(illuminant)
                       [ρ, γ, β] = Enum.chunk_every(data, 3)
                       data = %{gamma: gamma, illuminant: illuminant, ρ: ρ, γ: γ, β: β}

                       {String.to_atom(working_space), data}
                     end)
                     |> Map.new()

  @rgb_working_space_names Map.keys(@rgb_working_space)

  def rgb_working_spaces do
    @rgb_working_space
  end

  @doc """
  Returns the `(x, y)` chromaticities of a working space's three
  primaries plus its illuminant atom.

  ### Arguments

  * `working_space` is an atom identifying the working space,
    for example `:SRGB`, `:P3_D65`, `:Rec2020`.

  ### Returns

  * `%{red: {x, y}, green: {x, y}, blue: {x, y}, illuminant: atom}`.

  ### Examples

      iex> p = Color.RGB.WorkingSpace.primaries(:SRGB)
      iex> p.red
      {0.64, 0.33}

      iex> Color.RGB.WorkingSpace.primaries(:P3_D65).illuminant
      :D65

  """
  @spec primaries(atom()) :: %{
          red: {float(), float()},
          green: {float(), float()},
          blue: {float(), float()},
          illuminant: atom()
        }
  def primaries(working_space) when is_atom(working_space) do
    data = Map.fetch!(@rgb_working_space, working_space)
    [xr, yr, _] = Map.fetch!(data, :ρ)
    [xg, yg, _] = Map.fetch!(data, :γ)
    [xb, yb, _] = Map.fetch!(data, :β)

    %{
      red: {xr, yr},
      green: {xg, yg},
      blue: {xb, yb},
      illuminant: data.illuminant
    }
  end

  # CSS Color Module 4 working-space names → our internal atoms.
  @css_names %{
    "srgb" => :SRGB,
    "srgb-linear" => :SRGB,
    "display-p3" => :P3_D65,
    "a98-rgb" => :Adobe,
    "prophoto-rgb" => :ProPhoto,
    "rec2020" => :Rec2020,
    "rec709" => :Rec709
  }

  @doc """
  Looks up an RGB working space by its CSS Color 4 name.

  ### Arguments

  * `name` is a string.

  ### Returns

  * `{:ok, atom}` — the internal working-space atom.

  * `{:error, reason}` if the name is unknown.

  ### Examples

      iex> Color.RGB.WorkingSpace.from_css_name("display-p3")
      {:ok, :P3_D65}

      iex> Color.RGB.WorkingSpace.from_css_name("srgb")
      {:ok, :SRGB}

  """
  @spec from_css_name(String.t()) :: {:ok, atom()} | {:error, Exception.t()}
  def from_css_name(name) when is_binary(name) do
    case Map.fetch(@css_names, String.downcase(name)) do
      {:ok, atom} -> {:ok, atom}
      :error -> {:error, %Color.UnknownWorkingSpaceError{working_space: name}}
    end
  end

  @doc """
  Returns the CSS Color 4 name for an internal working-space atom,
  or `nil` if there isn't one.

  ### Arguments

  * `atom` is a working-space atom.

  ### Returns

  * A string or `nil`.

  ### Examples

      iex> Color.RGB.WorkingSpace.to_css_name(:P3_D65)
      "display-p3"

      iex> Color.RGB.WorkingSpace.to_css_name(:SRGB)
      "srgb"

      iex> Color.RGB.WorkingSpace.to_css_name(:Bruce)
      nil

  """
  @spec to_css_name(atom()) :: String.t() | nil
  def to_css_name(atom) when is_atom(atom) do
    @css_names
    |> Enum.find(fn {_, a} -> a == atom end)
    |> case do
      {name, _} -> name
      nil -> nil
    end
  end

  @doc """
  Returns the RGB→XYZ and XYZ→RGB conversion matrices for a named RGB
  working space, computed from its primaries and reference white using
  the Lindbloom formulas.

  ### Arguments

  * `rgb_space` is the working-space atom (for example `:sRGB`, `:Adobe`,
    `:ProPhoto`).

  ### Returns

  * An `{:ok, %{to_xyz: m, from_xyz: mi, illuminant: atom, observer_angle: 2}}`
    tuple where `m` and `mi` are 3x3 matrices represented as lists of rows.

  * `{:error, reason}` when the working space is unknown.

  ### Examples

      iex> {:ok, %{to_xyz: [[a, _, _] | _]}} = Color.RGB.WorkingSpace.rgb_conversion_matrix(:SRGB)
      iex> Float.round(a, 4)
      0.4125

  """
  @spec rgb_conversion_matrix(atom()) ::
          {:ok,
           %{
             to_xyz: list(),
             from_xyz: list(),
             illuminant: atom(),
             observer_angle: 2 | 10,
             gamma: term()
           }}
          | {:error, Exception.t()}
  def rgb_conversion_matrix(rgb_space) when rgb_space in @rgb_working_space_names do
    case :persistent_term.get({__MODULE__, :matrix, rgb_space}, :__uncached__) do
      :__uncached__ ->
        result = compute_conversion_matrix(rgb_space)
        :persistent_term.put({__MODULE__, :matrix, rgb_space}, result)
        result

      cached ->
        cached
    end
  end

  def rgb_conversion_matrix(rgb_space) do
    {:error,
     %Color.UnknownWorkingSpaceError{
       working_space: rgb_space,
       valid: @rgb_working_space_names
     }}
  end

  defp compute_conversion_matrix(rgb_space) do
    {:ok, working_space} = Map.fetch(rgb_working_spaces(), rgb_space)

    primaries = {
      List.to_tuple(Enum.take(working_space.ρ, 2)),
      List.to_tuple(Enum.take(working_space.γ, 2)),
      List.to_tuple(Enum.take(working_space.β, 2))
    }

    wr =
      Color.Tristimulus.reference_white_tuple(
        illuminant: working_space.illuminant,
        observer_angle: @rgb_observer_angle
      )

    m = Color.Conversion.Lindbloom.working_space_matrix(primaries, wr)
    mi = Color.Conversion.Lindbloom.invert3(m)

    {:ok,
     %{
       to_xyz: m,
       from_xyz: mi,
       illuminant: working_space.illuminant,
       observer_angle: @rgb_observer_angle,
       gamma: working_space.gamma
     }}
  end
end
